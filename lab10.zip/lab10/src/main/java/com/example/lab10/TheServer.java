package com.example.lab10;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.scene.Scene;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextArea;
import javafx.stage.Stage;
import java.io.DataInputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Date;

public class TheServer extends Application {
    private int clientID = 0;
    private final TextArea box = new TextArea();

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        box.setEditable(false);
        ScrollPane scrollPane = new ScrollPane(box);
        scrollPane.fitToHeightProperty().setValue(true);
        scrollPane.fitToWidthProperty().setValue(true);
        scrollPane.pannableProperty().setValue(true);
        Scene scene = new Scene(scrollPane,400,400);

        primaryStage.setScene(scene);
        primaryStage.setHeight(400);
        primaryStage.setWidth(400);
        primaryStage.setTitle("Bulletin Board");
        primaryStage.show();

        new Thread(()-> {
            try {
                ServerSocket serverSocket = new ServerSocket(6666);
                Platform.runLater(()-> box.appendText("Bulletin started " + new Date() + "\n"));
                while(true) {
                    Socket socket = serverSocket.accept();
                    clientID++;
                    Platform.runLater(()-> box.appendText("Client_" + clientID + " has joined the server." + "\n"));
                    new Thread(new ClientThread(socket)).start();
                }
            } catch(Exception e) {
                box.appendText(e + "\n");
            }
        }).start();
    }

    public class ClientThread implements Runnable {
        private final Socket socket;
        public ClientThread(Socket socket) { this.socket = socket; }
        @Override
        public void run() {
            try {
                DataInputStream inMsg = new DataInputStream(socket.getInputStream());
                while(true) {
                    String message = inMsg.readUTF();
                    Platform.runLater(() -> box.appendText("Messaged received: " + message + "\n"));
                }
            } catch(Exception e) {
                box.appendText(e + "\n");
            }
        }
    }
}
