package com.example.lab10;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.Socket;

public class TheClient extends Application {
    DataInputStream fromStream = null;
    DataOutputStream toStream = null;

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        Button exitButton = new Button("Exit");
        Button textButton = new Button("Send");

        BorderPane pane = new BorderPane();
        pane.setPadding(new Insets(5, 5, 5, 5));
        pane.setLeft(new Label());
        pane.setBottom(exitButton);
        pane.setLeft(textButton);

        TextField textField = new TextField();
        textField.setAlignment(Pos.BOTTOM_RIGHT);
        pane.setCenter(textField);

        BorderPane primaryPane = new BorderPane();
        TextArea textArea = new TextArea();
        textArea.setEditable(false);
        primaryPane.setCenter(new ScrollPane(textArea));
        primaryPane.setTop(pane);

        exitButton.setOnAction( e -> primaryStage.close() );

        Scene scene = new Scene(primaryPane, 500, 300);
        primaryStage.setHeight(300);
        primaryStage.setWidth(500);
        primaryStage.setTitle("User");
        primaryStage.setScene(scene);
        primaryStage.show();

        try {
            Socket socket = new Socket("localhost", 6666);
            fromStream = new DataInputStream(socket.getInputStream());
            toStream = new DataOutputStream(socket.getOutputStream());
        } catch(Exception e) {
            textArea.appendText(e + "\n");
        }

        textField.setOnAction(e -> {
            try {
                String message = textField.getText();
                toStream.writeUTF(message);
                toStream.flush();
                textArea.appendText("Sent: " + message + "\n");
                textField.clear();
            } catch (Exception ex) {
                textArea.appendText(ex + "\n");
            }
        });
    }
}
