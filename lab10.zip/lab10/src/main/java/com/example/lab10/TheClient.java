package com.example.lab10;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;

public class TheClient extends Application {
    DataInputStream fromStream = null;
    DataOutputStream toStream = null;

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        Button exitButton = new Button("Exit");
        Button textButton = new Button("Send");

        BorderPane pane = new BorderPane();
        pane.setPadding(new Insets(5, 5, 5, 5));
        pane.setLeft(new Label());
        pane.setBottom(exitButton);
        pane.setLeft(textButton);

        TextField textField = new TextField();
        textField.setAlignment(Pos.BOTTOM_RIGHT);
        pane.setCenter(textField);

        BorderPane primaryPane = new BorderPane();
        TextArea textArea = new TextArea();
        textArea.setEditable(false);

        ScrollPane scrollPane = new ScrollPane(textArea);
        scrollPane.fitToHeightProperty().setValue(true);
        scrollPane.fitToWidthProperty().setValue(true);
        scrollPane.pannableProperty().setValue(true);
        primaryPane.setCenter(scrollPane);
        primaryPane.setTop(pane);

        exitButton.setOnAction( e -> primaryStage.close() );

        Scene scene = new Scene(primaryPane, 400, 400);
        primaryStage.setHeight(400);
        primaryStage.setWidth(400);
        primaryStage.setTitle("User");
        primaryStage.setScene(scene);
        primaryStage.show();

        try {
            Socket socket = new Socket("localhost", 6666);
            fromStream = new DataInputStream(socket.getInputStream());
            toStream = new DataOutputStream(socket.getOutputStream());
        } catch(Exception e) {
            textArea.appendText(e + "\n");
        }

        textField.setOnAction(e -> {
            try {
                String message = textField.getText();
                textButton.setOnAction(e0-> {
                    try {
                        toStream.writeUTF(message);
                    } catch (IOException ex) {
                        ex.printStackTrace();
                    }
                    try {
                        toStream.flush();
                    } catch (IOException ex) {
                        ex.printStackTrace();
                    }
                    textArea.appendText("Sent: " + message + "\n");
                textField.clear();
                });
            } catch (Exception ex) {
                textArea.appendText(ex + "\n");
            }
        });
    }
}
