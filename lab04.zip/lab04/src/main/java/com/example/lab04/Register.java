package com.example.lab04;

import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.Scene;
import java.time.LocalDate;

public class Register extends Application {

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        Label username = new Label("Username: ");
        TextField user_id = new TextField();

        Label password = new Label("Password: ");
        PasswordField pwd_id = new PasswordField();

        Label fullName = new Label("Full Name: ");
        TextField name_id = new TextField();

        Label email = new Label("E-Mail: ");
        TextField email_id = new TextField();

        Label phoneNum = new Label("Phone #: ");
        TextField phone_id = new TextField();

        Label birthDate = new Label("Date of Birth: ");
        DatePicker birth = new DatePicker();

        Button button = new Button("Register");
        button.setOnAction(e-> {
            System.out.println(username.getText() + user_id.getText());
            System.out.println(password.getText() + pwd_id.getText());
            System.out.println(fullName.getText() + name_id.getText());
            System.out.println(email.getText() + email_id.getText());
            System.out.println(phoneNum.getText() + phone_id.getText());
            LocalDate d = birth.getValue();
            System.out.println(birthDate.getText() + d);
        });

        GridPane root = new GridPane();
        root.addRow(0, username, user_id);
        root.addRow(1, password, pwd_id);
        root.addRow(2, fullName, name_id);
        root.addRow(3, email, email_id);
        root.addRow(4, phoneNum, phone_id);
        root.addRow(5, birthDate, birth);
        root.addRow(6, button);

        GridPane.setConstraints(button, 1, 6);
        root.setVgap(7);

        Scene scene = new Scene(root,320,250);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Lab 04 Solution");
        primaryStage.show();
    }
}
